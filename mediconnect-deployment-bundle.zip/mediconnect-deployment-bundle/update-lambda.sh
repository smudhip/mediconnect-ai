#!/bin/bash

# Update Lambda function with enhanced code

STACK_NAME="mediconnect-ai"
REGION="${AWS_REGION:-us-east-1}"
FUNCTION_NAME="${STACK_NAME}-analysis"

echo "🔄 Updating Lambda function..."

# Create deployment package
zip -q lambda-deployment.zip lambda-function.py

# Update function code
aws lambda update-function-code \
    --function-name $FUNCTION_NAME \
    --zip-file fileb://lambda-deployment.zip \
    --region $REGION

# Update handler
aws lambda update-function-configuration \
    --function-name $FUNCTION_NAME \
    --handler lambda-function.lambda_handler \
    --region $REGION

# Clean up
rm lambda-deployment.zip

echo "✅ Lambda function updated!"
