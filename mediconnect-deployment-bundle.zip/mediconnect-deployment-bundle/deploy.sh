#!/bin/bash

# MediConnect AI Deployment Script
# This script deploys the complete infrastructure to AWS

set -e

STACK_NAME="mediconnect-ai"
REGION="${AWS_REGION:-us-east-1}"

echo "🚀 MediConnect AI Deployment"
echo "=============================="
echo "Stack Name: $STACK_NAME"
echo "Region: $REGION"
echo ""

# Check AWS CLI
if ! command -v aws &> /dev/null; then
    echo "❌ AWS CLI not found. Please install it first."
    exit 1
fi

# Check AWS credentials
if ! aws sts get-caller-identity &> /dev/null; then
    echo "❌ AWS credentials not configured. Run 'aws configure' first."
    exit 1
fi

echo "✅ AWS credentials verified"
echo ""

# Deploy CloudFormation stack
echo "📦 Deploying CloudFormation stack..."
aws cloudformation deploy \
    --template-file cloudformation-template.yaml \
    --stack-name $STACK_NAME \
    --parameter-overrides StackName=$STACK_NAME \
    --capabilities CAPABILITY_NAMED_IAM \
    --region $REGION

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Deployment successful!"
    echo ""
    
    # Get outputs
    echo "📋 Stack Outputs:"
    API_ENDPOINT=$(aws cloudformation describe-stacks \
        --stack-name $STACK_NAME \
        --region $REGION \
        --query 'Stacks[0].Outputs[?OutputKey==`ApiEndpoint`].OutputValue' \
        --output text)
    
    LAMBDA_ARN=$(aws cloudformation describe-stacks \
        --stack-name $STACK_NAME \
        --region $REGION \
        --query 'Stacks[0].Outputs[?OutputKey==`LambdaFunctionArn`].OutputValue' \
        --output text)
    
    echo "  API Endpoint: $API_ENDPOINT"
    echo "  Lambda ARN: $LAMBDA_ARN"
    echo ""
    
    # Test the endpoint
    echo "🧪 Testing API endpoint..."
    RESPONSE=$(curl -s -X POST "$API_ENDPOINT" \
        -H "Content-Type: application/json" \
        -d '{"test": "connection"}')
    
    if echo "$RESPONSE" | grep -q "online"; then
        echo "✅ API is responding correctly!"
        echo "Response: $RESPONSE"
    else
        echo "⚠️  API response: $RESPONSE"
    fi
    
    echo ""
    echo "🎉 Deployment complete!"
    echo ""
    echo "Next steps:"
    echo "1. Update your HTML file with the API endpoint:"
    echo "   const AWS_ENDPOINT = '$API_ENDPOINT';"
    echo ""
    echo "2. Test the API:"
    echo "   curl -X POST '$API_ENDPOINT' -H 'Content-Type: application/json' -d '{\"test\": \"connection\"}'"
    
else
    echo "❌ Deployment failed"
    exit 1
fi
