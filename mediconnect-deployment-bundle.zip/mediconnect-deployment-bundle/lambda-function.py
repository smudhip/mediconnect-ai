import json

def lambda_handler(event, context):
    """
    MediConnect AI Lambda Function
    Analyzes patient medical data and returns comprehensive insights
    """
    headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type'
    }
    
    # Handle OPTIONS for CORS
    if event.get('httpMethod') == 'OPTIONS':
        return {'statusCode': 200, 'headers': headers, 'body': ''}
    
    try:
        body = json.loads(event.get('body', '{}'))
        
        # Health check
        if body.get('test') == 'connection':
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps({
                    'status': 'online',
                    'message': 'MediConnect AI Backend is healthy',
                    'version': '1.0'
                })
            }
        
        # Analyze patient data
        patient_data = body.get('patient_data', {})
        analysis = analyze_patient(patient_data)
        
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps(analysis)
        }
        
    except Exception as e:
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({
                'patterns': [],
                'alerts': [],
                'recommendations': [],
                'risk_level': 'UNKNOWN',
                'confidence': 0.5,
                'error': str(e)
            })
        }

def analyze_patient(data):
    """Analyze patient medical data"""
    conditions = data.get('medical_conditions', [])
    symptoms = data.get('current_symptoms', '').lower()
    history = data.get('medical_history', [])
    
    patterns = []
    alerts = []
    recommendations = []
    risk_level = 'MODERATE'
    confidence = 85
    
    # Extract condition names
    condition_names = [c.get('condition', '').lower() for c in conditions]
    history_items = [h.lower() for h in history] if isinstance(history, list) else []
    
    # Kidney disease analysis
    if any('kidney' in name for name in condition_names) or 'kidney_disease' in history_items:
        patterns.append({
            'type': 'CHRONIC_KIDNEY_DISEASE',
            'description': 'Requires medication dose adjustments and regular monitoring',
            'severity': 'HIGH'
        })
        recommendations.extend([
            'Monthly kidney function tests (Creatinine, GFR, BUN)',
            'Nephrology consultation for medication review',
            'Electrolyte monitoring (K, P, Ca)',
            'Low sodium diet, protein restriction if GFR <30'
        ])
        alerts.append('Medication doses must be adjusted for kidney function')
        risk_level = 'HIGH'
        confidence = 92
    
    # Thyroid disorder analysis
    if any('thyroid' in name for name in condition_names):
        patterns.append({
            'type': 'THYROID_DISORDER',
            'description': 'Thyroid hormone levels affect metabolism and multiple organ systems',
            'severity': 'MODERATE'
        })
        recommendations.extend([
            'TSH, Free T3, Free T4 monitoring every 6-8 weeks',
            'Endocrinology consultation for dose adjustment',
            'Monitor for cardiac effects'
        ])
        
        # Kidney-thyroid interaction
        if any('kidney' in name for name in condition_names):
            patterns.append({
                'type': 'KIDNEY_THYROID_INTERACTION',
                'description': 'Kidney disease alters thyroid hormone metabolism',
                'severity': 'HIGH'
            })
            alerts.append('CRITICAL: Thyroid medication requires dose adjustment in kidney disease')
            risk_level = 'HIGH'
    
    # Diabetes analysis
    if any('diabetes' in name for name in condition_names) or 'diabetes_history' in history_items:
        patterns.append({
            'type': 'DIABETES_COMPLICATIONS',
            'description': 'Requires blood sugar control and complication screening',
            'severity': 'HIGH'
        })
        recommendations.extend([
            'HbA1c every 3 months (target <7%)',
            'Daily blood glucose monitoring',
            'Annual dilated eye exam',
            'Daily foot inspection',
            'Annual kidney function screening'
        ])
        risk_level = 'HIGH'
        
        # Diabetic nephropathy
        if any('kidney' in name for name in condition_names):
            patterns.append({
                'type': 'DIABETIC_NEPHROPATHY',
                'description': 'Diabetes damaging kidneys - aggressive management critical',
                'severity': 'CRITICAL'
            })
            alerts.append('CRITICAL: Diabetic kidney disease requires strict blood sugar control')
            risk_level = 'CRITICAL'
            confidence = 96
    
    # Cardiac analysis
    if any('cardiac' in name or 'heart' in name for name in condition_names):
        patterns.append({
            'type': 'CARDIAC_CONDITION',
            'description': 'Heart condition requires monitoring and medication optimization',
            'severity': 'HIGH'
        })
        recommendations.extend([
            'ECG and echocardiogram',
            'BNP levels monitoring',
            'Heart failure medication optimization'
        ])
        risk_level = 'HIGH'
    
    # Hypertension
    if 'hypertension' in history_items:
        patterns.append({
            'type': 'HYPERTENSION',
            'description': 'High blood pressure increases cardiovascular and kidney risk',
            'severity': 'MODERATE'
        })
        recommendations.append('Blood pressure target <130/80 mmHg')
    
    # Multi-condition risk
    if len(patterns) > 2:
        alerts.append('Multiple conditions require coordinated specialist care')
        risk_level = 'HIGH'
    
    return {
        'patterns': patterns,
        'alerts': alerts,
        'recommendations': recommendations,
        'risk_level': risk_level,
        'confidence': confidence,
        'backend_status': 'AWS Lambda Processing'
    }
