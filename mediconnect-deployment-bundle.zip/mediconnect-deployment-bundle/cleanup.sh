#!/bin/bash

# MediConnect AI Cleanup Script
# This script removes all deployed resources

set -e

STACK_NAME="mediconnect-ai"
REGION="${AWS_REGION:-us-east-1}"

echo "🗑️  MediConnect AI Cleanup"
echo "=========================="
echo "Stack Name: $STACK_NAME"
echo "Region: $REGION"
echo ""

read -p "Are you sure you want to delete the stack? (yes/no): " CONFIRM

if [ "$CONFIRM" != "yes" ]; then
    echo "❌ Cleanup cancelled"
    exit 0
fi

echo "🗑️  Deleting CloudFormation stack..."
aws cloudformation delete-stack \
    --stack-name $STACK_NAME \
    --region $REGION

echo "⏳ Waiting for stack deletion..."
aws cloudformation wait stack-delete-complete \
    --stack-name $STACK_NAME \
    --region $REGION

echo "✅ Stack deleted successfully!"
