# MediConnect AI - Deployment Bundle

Complete AWS infrastructure deployment package with API Gateway and Lambda.

## 📦 Contents

- `cloudformation-template.yaml` - Complete infrastructure as code
- `deploy.sh` - Automated deployment script
- `cleanup.sh` - Resource cleanup script
- `lambda-function.py` - Enhanced Lambda function code
- `update-lambda.sh` - Lambda code update script
- `README.md` - This file

## 🚀 Quick Start

### Prerequisites

1. **AWS CLI installed**
   ```bash
   aws --version
   ```

2. **AWS credentials configured**
   ```bash
   aws configure
   ```

3. **Permissions required:**
   - CloudFormation
   - Lambda
   - API Gateway
   - IAM (for role creation)
   - CloudWatch Logs

### Deploy

```bash
./deploy.sh
```

This will:
1. Create Lambda function with medical analysis logic
2. Create API Gateway with CORS support
3. Set up IAM roles and permissions
4. Deploy to production stage
5. Test the endpoint
6. Display the API endpoint URL

### Update Lambda Code

After deployment, to update just the Lambda function:

```bash
./update-lambda.sh
```

### Cleanup

To remove all resources:

```bash
./cleanup.sh
```

## 📋 What Gets Deployed

### Lambda Function
- **Name:** `mediconnect-ai-analysis`
- **Runtime:** Python 3.11
- **Memory:** 256 MB
- **Timeout:** 30 seconds
- **Features:**
  - Health check endpoint
  - Kidney disease analysis
  - Thyroid disorder analysis
  - Diabetes analysis
  - Cardiac condition analysis
  - Multi-condition interaction detection

### API Gateway
- **Name:** `mediconnect-ai-api`
- **Stage:** `prod`
- **Endpoint:** `/analyze`
- **Methods:** POST, OPTIONS (CORS)
- **CORS:** Enabled for all origins

### IAM Role
- **Name:** `mediconnect-ai-lambda-role`
- **Permissions:**
  - CloudWatch Logs (for monitoring)
  - Lambda execution

## 🧪 Testing

### Health Check
```bash
curl -X POST https://YOUR-API-ID.execute-api.us-east-1.amazonaws.com/prod/analyze \
  -H "Content-Type: application/json" \
  -d '{"test": "connection"}'
```

Expected response:
```json
{
  "status": "online",
  "message": "MediConnect AI Backend is healthy",
  "version": "1.0"
}
```

### Medical Analysis
```bash
curl -X POST https://YOUR-API-ID.execute-api.us-east-1.amazonaws.com/prod/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "patient_data": {
      "medical_conditions": [
        {"condition": "Chronic Kidney Disease"}
      ],
      "medical_history": ["diabetes_history"],
      "current_symptoms": "fatigue, swelling"
    }
  }'
```

## 🔧 Configuration

### Change Stack Name
Edit `deploy.sh` and modify:
```bash
STACK_NAME="your-custom-name"
```

### Change Region
Set environment variable:
```bash
export AWS_REGION=us-west-2
./deploy.sh
```

Or edit the scripts directly.

### Customize Lambda
Edit `lambda-function.py` and run:
```bash
./update-lambda.sh
```

## 📊 Monitoring

### View Lambda Logs
```bash
aws logs tail /aws/lambda/mediconnect-ai-analysis --follow
```

### Check API Gateway Metrics
```bash
aws cloudwatch get-metric-statistics \
  --namespace AWS/ApiGateway \
  --metric-name Count \
  --dimensions Name=ApiName,Value=mediconnect-ai-api \
  --start-time 2025-01-01T00:00:00Z \
  --end-time 2025-12-31T23:59:59Z \
  --period 3600 \
  --statistics Sum
```

## 🔐 Security

- API Gateway has no authentication (public endpoint)
- CORS enabled for all origins
- Lambda has minimal IAM permissions
- No sensitive data stored

**For production:**
- Add API key authentication
- Restrict CORS origins
- Enable AWS WAF
- Add request throttling
- Enable CloudWatch alarms

## 💰 Cost Estimate

**Monthly costs (assuming 10,000 requests/month):**
- Lambda: ~$0.20
- API Gateway: ~$0.35
- CloudWatch Logs: ~$0.50
- **Total: ~$1.05/month**

Free tier eligible for first 12 months.

## 🔄 Update HTML with API Endpoint

After deployment, update your HTML file:

```javascript
const AWS_ENDPOINT = 'https://YOUR-API-ID.execute-api.us-east-1.amazonaws.com/prod/analyze';
```

The deploy script will show you the exact URL.

## 🐛 Troubleshooting

### Deployment fails
- Check AWS credentials: `aws sts get-caller-identity`
- Verify IAM permissions
- Check CloudFormation events in AWS Console

### API returns 500 error
- Check Lambda logs: `aws logs tail /aws/lambda/mediconnect-ai-analysis`
- Verify Lambda has correct handler: `lambda-function.lambda_handler`
- Test Lambda directly in AWS Console

### CORS errors
- Verify OPTIONS method is deployed
- Check API Gateway CORS configuration
- Redeploy API: `./deploy.sh`

## 📞 Support

For issues or questions:
1. Check CloudFormation stack events
2. Review Lambda CloudWatch logs
3. Test Lambda function directly in AWS Console
4. Verify API Gateway configuration

## 📄 License

MIT License - See main project LICENSE file
