# MediConnect AI - Web Demo Bundle

## 📦 Contents

- `agentic-medical-interface.html` - Interactive web-based medical analysis demo

## 🚀 How to Use

### Option 1: Open Directly
Simply double-click `agentic-medical-interface.html` to open in your browser.

### Option 2: Command Line
```bash
open agentic-medical-interface.html
```

## 🎯 What This Demo Does

This is a fully self-contained web interface that demonstrates MediConnect AI's multi-agent medical analysis system.

**Features:**
- Interactive patient data input
- Real-time multi-agent analysis simulation
- 6 specialized AI agents working together
- Visual pattern recognition
- Risk assessment with confidence scores
- Family-friendly medical explanations
- Critical alerts and recommendations

**The 6 AI Agents:**
1. 📊 Clinical Data Analysis Agent
2. 🔍 Pattern Recognition Agent
3. ⚠️ Risk Assessment Agent
4. 💬 Patient Communication Agent
5. 📚 Medical Knowledge Agent
6. 🎯 Clinical Decision Support Agent

## 💡 Demo Scenario

Pre-loaded with the case of Margaret Johnson (67-year-old):
- Chronic knee pain (years)
- New bilateral leg swelling (3 months)
- Previous cardiac history
- Scheduled for knee surgery

**Key Insight:** The demo shows how MediConnect AI identifies that leg swelling is from undiagnosed heart failure, not knee problems, preventing dangerous surgery.

## 🔧 Technical Details

- **Type:** Single-page HTML application
- **Dependencies:** None (fully self-contained)
- **Backend:** Connected to AWS Lambda API
- **Styling:** Embedded CSS
- **JavaScript:** Embedded (no external libraries)

## 📝 Notes

- No installation required
- Works offline for UI (backend requires internet)
- Compatible with all modern browsers
- Mobile-responsive design
